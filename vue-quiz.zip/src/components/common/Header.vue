<template>
  <header>
    <router-link to="/">Home</router-link>
    <template v-if="!isLoggedIn">
      <router-link to="/login">Login</router-link>
      <router-link to="/register">Register</router-link>
    </template>
    <template v-else>
      <button>Logout</button>
    </template>
  </header>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false,
    };
  },
  methods: {

  }
};
</script>

<style scoped>
</style>