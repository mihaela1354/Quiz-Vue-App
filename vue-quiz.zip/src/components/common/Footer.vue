<template>
  <footer>
    <div>
      © {{getYear}} Copyright:
      <router-link to="/">QuizPlatform.com</router-link>
    </div>
  </footer>
</template>

<script>
export default {
  data() {
    return {
    };
  },
  computed: {
    getYear() {
      return new Date().getFullYear();
    }
  }
};
</script>

<style scoped>
</style>