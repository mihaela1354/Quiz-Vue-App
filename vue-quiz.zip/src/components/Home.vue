<template>
  <section>
    <ul class="quiz-step step1 current">
      <li class="quiz" v-for="quiz in quizList" :key="quiz.id">
        <div>
          <router-link :to="{ name: 'Questions', params: { id: quiz.id }}">{{quiz.title}}</router-link>
          <router-link :to="{ name: 'edit', params: { id: quiz.id }}">Edit</router-link>
        </div>
      </li>
      <div>
        <router-link to="/quiz/add">Add Quiz</router-link>
      </div>
    </ul>
  </section>
</template>

<script>
import quizes from "@/data/quizes.json";

export default {
  data() {
    return {
      quizList: quizes
    };
  }
};
</script>

<style>
</style>