<template>
  <div>
    <div>
      <div>
        <div>
          <h3>Login</h3>
          <div>
            <span>
              <i class="fab fa-facebook-square"></i>
            </span>
            <span>
              <i class="fab fa-google-plus-square"></i>
            </span>
            <span>
              <i class="fab fa-twitter-square"></i>
            </span>
          </div>
        </div>
        <div>
          <form @submit.prevent="login">
            <div>
              <div>
                <span>
                  <i class="fas fa-user"></i>
                </span>
              </div>
              <input v-model="username" type="text" name="username" placeholder="username" />
            </div>
            <div>
              <div>
                <span>
                  <i class="fas fa-key"></i>
                </span>
              </div>
              <input v-model="password" type="password" name="password" placeholder="password" />
            </div>

            <input type="submit" value="Login" />
          </form>
        </div>
        <div>
          <div>
            Don't have an account?
            <router-link class="text-warning" to="/register">Register</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    login() {
      console.log(this.username);
      console.log('Logging In!');
    }
  }
};
</script>

<style scoped>
</style>