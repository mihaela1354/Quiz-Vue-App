<template>
  <div>
    <template v-if="hasQuestions">
      <h2>Question #{{questionNumber}}: {{currentQuestion.title}}</h2>
      <form @submit.prevent="loadNextQuestion">
        <div v-for="(answer, index) in currentQuestion.answers" :key="index">
          <label>{{answer.content}}</label>
          <input type="radio" :value="answer.content" v-model="currentQuestionAnswer" />
        </div>

        <input type="submit" value="Next" />
      </form>
    </template>
    <template v-else>
      <h1>Your score is:</h1>
      <p>{{scorePercentage}}/100</p>
    </template>
  </div>
</template>

<script>
import questions from "@/data/questions.json";
import quizes from "@/data/quizes.json";

export default {
  data() {
    return {
      quizId: this.$route.params.id,
      quiz: null,
      questions: [],
      currentQuestion: null,
      hasQuestions: true,
      currentQuestionAnswer: "",
      rightAnswer: "",
      questionNumber: 1,
      score: 0
    };
  },
  created() {
    this.quiz = quizes[this.quizId];
    this.quiz.questionIds.forEach(id => {
      this.questions.push(questions[id]);
    });

    this.currentQuestion = this.questions.shift();
    this.rightAnswer = this.currentQuestion.answers.find(
      q => q.isRight
    ).content;
  },
  methods: {
    loadNextQuestion() {
      if (this.currentQuestionAnswer === "") {
        return;
      }

      if (this.currentQuestionAnswer === this.rightAnswer) {
        this.score++;
      }

      this.currentQuestion = this.questions.shift();
      this.hasQuestions = this.currentQuestion !== undefined;
      if (this.currentQuestion) {
        this.questionNumber++;
        this.rightAnswer = this.currentQuestion.answers.find(
          q => q.isRight
        ).content;
      }
    }
  },
  computed: {
    scorePercentage() {
      return Math.trunc((this.score / this.questionNumber) * 100);
    }
  }
};
</script>

<style>
</style>